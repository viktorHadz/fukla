### `npm install`

### `npm start`
