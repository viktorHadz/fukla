import { Link } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import { Menu } from "./Menu";

export const Header = () => {
    const [scrollPosition, setScrollPosition] = useState(0);
    const [transparent, setTransparent] = useState(1);
    const [visibility, setVisibility] = useState(0);

    useEffect(() => {
        function handleScroll() {
            if(scrollPosition < 150){
                setTransparent(true);
            }
            else{
                setTransparent(false);
            }
            if(scrollPosition > window.pageYOffset || window.pageYOffset < 95){
                setVisibility(false);
            }else{
                setVisibility(true);
            }
          setScrollPosition(window.pageYOffset);
        }
    
        window.addEventListener('scroll', handleScroll);
    
        return () => {
          window.removeEventListener('scroll', handleScroll);
        };
    });

      const holder = visibility ? 'header nav__hidden' : 'header';

      const navStyles = holder + (transparent ? ' transparent' : '');

      const linkStyles = transparent ? 'header__link transparent' : 'header__link';

      const hamStyles = transparent ? 'header__menu transparent' : 'header__menu';

    return (
        <header className={navStyles}>
            <div className="header__logo">
                <h1 className="logo__text"><span className="logo__text__span">F</span>ukla</h1>
            </div>

            <div className="header__links">
                <Link to="/" className={linkStyles}>Начало</Link>
                <Link to="/braids" className={linkStyles}>Плитки</Link>
                {/* <Link to="/makeup" className={linkStyles}>Грим</Link> */}
                <Link to="/nails" className={linkStyles}>Маникюр</Link>
            </div>

            <div className={hamStyles}>
                <Menu />
            </div>
        </header>
    );
};