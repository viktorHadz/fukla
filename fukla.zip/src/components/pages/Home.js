import { Hero } from "./home/Hero";
import { OurServices } from "./home/OurServices";
import { Services } from "./home/Services";
import { Instagram } from "./home/Instagram";
import ScrollToTopOnMount from '../ScrollToTopOnMount';

export const Home = () => {
    return (
    <>
        <ScrollToTopOnMount />
        <Hero />
        <OurServices />
        <Services />
        <Instagram />
    </>
    );
};