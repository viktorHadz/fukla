export const BraidsDivider = () => {
    return (
        <section className="braidsdivider">
            <h2 className="braidsdivider__title">Моята работа</h2>
        </section>
    );
};