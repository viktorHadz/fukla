export const Instagram = () => {
    return (
        <section className="instagram">
            <h2 className="instagram__title">Instagram</h2>
            <a className="instagram__button" target="_blank" rel="noreferrer" href="https://www.instagram.com/artstudio.fukla/">Последвайте ни на @artstudio.fukla</a>
        </section>
    );
};