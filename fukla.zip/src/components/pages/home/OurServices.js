export const OurServices = () => {
    return (
        <section className="ourservices">
            <h2 className="ourservices__title">Какво предлагаме?</h2>
            <div className="ourservices__allservices">
                <div className="ourservices__service">
                    <img className="ourservices__service__image" src="./images/home/icons/nailsIcon.png" alt="icon"/>
                    <h3 className="ourservices__service__subtitle">Маникюр</h3>
                </div>
                <div className="ourservices__service">
                    <img className="ourservices__service__image" src="./images/home/icons/HairIcon.png" alt="icon"/>
                    <h3 className="ourservices__service__subtitle">Плитки</h3>
                </div>
                <div className="ourservices__service">
                    <img className="ourservices__service__image" src="./images/home/icons/MakeupIcon.png" alt="icon"/>
                    <h3 className="ourservices__service__subtitle">Грим</h3>
                </div>
            </div>
        </section>
    );
};