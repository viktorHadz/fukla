import { Link } from 'react-router-dom';

export const Services = () => {
    return (
        <>
            <section className="services">
                <div className="services__box">
                    <div className="services__image">
                        <img className="services__img" src="/images/home/braids.webp" alt="Braids" />
                    </div>
                    <div className="services__text">
                        <h2 className="services__title">Плитки</h2>
                        <span className="services__subtitle">Косата е короната, която никога не сваляте и с правилната грижа и оформяне тя може да бъде блестящо свидетелство за вашата красота и увереност.</span>
                        <span className="services__subtitle">Косата е отражение на това кой сте и какво представлявате, а с правилния стил тя може да бъде мощен израз на вашата идентичност.</span>
                        <div className="services__button__div">
                            <Link to='/braids' className="services__button">прочети повече</Link>
                        </div>
                    </div>
                </div>
            </section>
            <section className="services reversed">
                <div className="services__box reversed">
                    <div className="services__image">
                        <img className="services__img" src="/images/home/makeup.webp" alt="Makeup" />
                    </div>
                    <div className="services__text reversed">
                        <h2 className="services__title reversed">Грим</h2>
                        <span className="services__subtitle reversed">Гримът не е маска, която прикрива вашата красота, това е оръжие, което ви помага да изразите кой сте отвътре.</span>
                        <span className="services__subtitle reversed">Красотата на грима е, че може да се използва за подчертаване на естествената красота, която вече съществува, вместо да се опитва да я прикрие или промени напълно.</span>
                        <div className="services__button__div">
                            <Link to='' className="services__button">търси се</Link>
                        </div>
                    </div>
                </div>
            </section>
            <section className="services">
                <div className="services__box">
                    <div className="services__image">
                        <img className="services__img" src="/images/home/nails.webp" alt="Nails" />
                    </div>
                    <div className="services__text">
                        <h2 className="services__title">Маникюр</h2>
                        <span className="services__subtitle">Маникюрът е като бижу за вашите ръце, той добавя блясък и красота към вашия външен вид.</span>
                        <span className="services__subtitle">Маникюрът е форма на изкуство и с правилните инструменти и техники можете да създавате красиви и уникални дизайни.</span>
                        <div className="services__button__div">
                            <Link to='/nails' className="services__button">прочети повече</Link>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};